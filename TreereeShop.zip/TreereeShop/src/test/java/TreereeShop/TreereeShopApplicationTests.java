package TreereeShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreereeShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
