package com.devmaster.lesson01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson01SpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
